// waffle.typ - Waffle chart (grid of squares showing proportions)
#import "../theme.typ": _resolve-ctx, get-color
#import "../util.typ": normalize-data, nonzero
#import "../validate.typ": validate-simple-data
#import "../primitives/container.typ": chart-container
#import "../primitives/legend.typ": draw-legend-auto
#import "../primitives/layout.typ": resolve-size

/// Renders a waffle chart — a grid of squares where each square represents
/// a unit or percentage of the total. Commonly used in infographics to
/// show proportions at a glance.
///
/// Values are normalized to percentages if they don't sum to 100.
/// Squares fill left-to-right, bottom-to-top with category colors.
///
/// - data (dictionary, array): Label-value pairs as dict or array of tuples
/// - size (length): Overall chart width and height for the grid area
/// - rows (int): Number of rows in the grid
/// - cols (int): Number of columns in the grid
/// - gap (length): Spacing between squares
/// - rounded (bool): Whether squares have rounded corners
/// - title (none, content): Optional chart title
/// - show-legend (bool): Display legend with category names and colors
/// - show-values (bool): Display percentage labels in the legend
/// - theme (none, dictionary): Theme overrides
/// - extra-legend-separation (length): Extra space between legend and chart
/// -> content
#let waffle-chart(
  data,
  size: 200pt,
  rows: 10,
  cols: 10,
  gap: 2pt,
  rounded: true,
  title: none,
  show-legend: true,
  show-values: true,
  theme: none,
  extra-legend-separation: 0pt,
) = context {
  layout(avail => {
  validate-simple-data(data, "waffle-chart")
  let t = _resolve-ctx(theme)
  let size = resolve-size(size, size, avail).width

  // Shrink grid size if total width (grid + legend + padding) exceeds available space
  let legend-overhead = if show-legend { 120pt + 10pt } else { 0pt }
  let pad2 = 16pt  // 2 * container-inset
  let avail-w = if type(avail.width) == length and avail.width > 0pt { avail.width } else { none }
  if avail-w != none and size + legend-overhead + pad2 > avail-w {
    size = avail-w - legend-overhead - pad2
  }

  let norm = normalize-data(data)
  let labels = norm.labels
  let values = norm.values
  let n = labels.len()
  let total-cells = rows * cols

  // Normalize values to percentages of total-cells
  let raw-sum = nonzero(values.sum())
  let cell-counts = values.map(v => int(calc.round(v / raw-sum * total-cells)))

  // Adjust rounding so cell-counts sum to exactly total-cells
  let allocated = cell-counts.sum()
  if allocated != total-cells and n > 0 {
    // Add or remove from the largest category
    let max-idx = 0
    let max-val = cell-counts.at(0)
    for i in range(1, n) {
      if cell-counts.at(i) > max-val {
        max-val = cell-counts.at(i)
        max-idx = i
      }
    }
    cell-counts.at(max-idx) = cell-counts.at(max-idx) + (total-cells - allocated)
  }

  // Build a flat array mapping each cell index to a category index
  // Cells fill bottom-to-top, left-to-right
  let cell-colors = ()
  for (cat-idx, count) in cell-counts.enumerate() {
    for _ in range(count) {
      cell-colors.push(cat-idx)
    }
  }

  // Compute square size from available space
  let cell-w = (size - gap * (cols - 1)) / cols
  let cell-h = (size - gap * (rows - 1)) / rows
  let cell-size = calc.min(cell-w, cell-h)
  let radius = if rounded { 2pt } else { 0pt }

  // Compute percentages for legend display
  let percentages = values.map(v => calc.round(v / raw-sum * 100, digits: 1))

  // Build legend entries — compact format
  let legend-entries = ()
  if show-legend {
    for i in range(n) {
      let pct = str(percentages.at(i)) + "%"
      let label-text = if show-values { labels.at(i) + " (" + pct + ")" } else { labels.at(i) }
      legend-entries.push(label-text)
    }
  }

  // Compute actual grid dimensions
  let grid-width = cell-size * cols + gap * (cols - 1)
  let grid-height = cell-size * rows + gap * (rows - 1)

  // Force legend to right side for waffle charts
  let wt = (..t, legend-position: "right")
  let legend-content = draw-legend-auto(legend-entries, wt, show-legend: show-legend)

  align(center, chart-container(size, grid-height, title, wt, legend: legend-content, extra-legend-separation: extra-legend-separation)[
    // Draw grid bottom-to-top, left-to-right
    #box(width: size, height: grid-height)[
      #align(center + top)[
        #box(width: grid-width, height: grid-height)[
          #for row in range(rows) {
            // bottom-to-top: row 0 is the bottom row visually
            let visual-row = rows - 1 - row
            for col in range(cols) {
              let cell-idx = row * cols + col
              let cat-idx = if cell-idx < cell-colors.len() {
                cell-colors.at(cell-idx)
              } else {
                0
              }
              let color = get-color(t, cat-idx)
              place(
                dx: col * (cell-size + gap),
                dy: visual-row * (cell-size + gap),
                rect(
                  width: cell-size,
                  height: cell-size,
                  fill: color,
                  radius: radius,
                ),
              )
            }
          }
        ]
      ]
    ]

  ])
  })
}
